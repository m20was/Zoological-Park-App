﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MongoDB.Bson;


namespace dbmsapp
{
    class Class1
    {
        public ObjectId _id { get; set; }
        public int rno { get; set; }
        public string name { get; set; }
        public int marks { get; set; }



    }
}
