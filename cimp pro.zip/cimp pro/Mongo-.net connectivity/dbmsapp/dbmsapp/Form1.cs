﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Builders;


namespace dbmsapp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            MongoClient client = new MongoClient("mongodb://localhost");
            MongoServer server = client.GetServer();
            MongoDatabase db = server.GetDatabase("dbtest");
            MongoCollection<BsonDocument> student = db.GetCollection<BsonDocument>("Student");
            BsonDocument stud = new BsonDocument
            {
                {"rno",Convert.ToInt32(textBox1.Text.Trim())},
                {"name",textBox2.Text.Trim()},
                {"marks",Convert.ToInt32(textBox3.Text.Trim())}
            };
            student.Insert(stud);
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        { MongoClient client = new MongoClient("mongodb://localhost");
            MongoServer server = client.GetServer();
            MongoDatabase db = server.GetDatabase("dbtest");
            MongoCollection<Class1> stud = db.GetCollection<Class1>("Student");
            foreach (Class1 i in stud.Find(Query.EQ("rno", Convert.ToInt32(textBox1.Text.Trim()))))
            {
                IMongoUpdate update1 = new UpdateDocument();
                IMongoUpdate update2 = new UpdateDocument();
                if (textBox1.Text != "")
                {
                    update1 = MongoDB.Driver.Builders.Update.Set("name", textBox2.Text);
                    update2 = MongoDB.Driver.Builders.Update.Set("marks", Convert.ToInt32(textBox3.Text));
                }
                stud.Update(Query.EQ("rno", Convert.ToInt32(textBox1.Text)), update1);
                stud.Update(Query.EQ("rno", Convert.ToInt32(textBox1.Text)), update2);
                MessageBox.Show("Updated");
                //  refresh();
                break;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            MongoClient client = new MongoClient("mongodb://localhost");
            MongoServer server = client.GetServer();
            MongoDatabase db = server.GetDatabase("dbtest");
            MongoCollection<Class1> student = db.GetCollection<Class1>("Student");
            if (student.Remove(Query.EQ("rno", Convert.ToInt32(textBox1.Text))).Ok == true)
                MessageBox.Show("Record successfully deleted!");
            else
                MessageBox.Show("Record Not Found deleted!");
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            refresh();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
textBox1.Text = dataGridView1.SelectedCells[0].Value.ToString();
           textBox2.Text = dataGridView1.SelectedCells[1].Value.ToString();
           textBox3.Text = dataGridView1.SelectedCells[2].Value.ToString();
        }
        private void refresh()
        {
            try
            {
                MongoClient client = new MongoClient("mongodb://localhost");
                MongoServer server = client.GetServer();
                MongoDatabase db = server.GetDatabase("dbtest");
                MongoCursor<Class1> put = db.GetCollection<Class1>("Student").FindAll();
                dataGridView1.RowCount = 1;
                foreach (Class1 i in put)
                {
                    dataGridView1.Rows.Add(Convert.ToString(i.rno), Convert.ToString(i.name), Convert.ToString(i.marks));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        //private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        //{
        //    
        //}
    }
}
