﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Builders;

namespace myapp
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
   
        private void button1_Click(object sender, EventArgs e)
        {
            MongoServer mongo = MongoServer.Create();
            mongo.Connect();
            MongoDatabase db;

            db = mongo.GetDatabase("Library");
         //   var collection = db.GetCollection("books");
            MongoCollection<Info> Persons = db.GetCollection<Info>("books");
            foreach (Info mybk in Persons.FindAll())
            {
                this.textBox1.Text = mybk.ID;
                this.textBox2.Text=mybk.Bname;
               /// dataGridView1.DataSource = mybk;




            }

        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            MongoServer mongo = MongoServer.Create();
            mongo.Connect();
            MongoDatabase db;

            db = mongo.GetDatabase("Library");
         
            MongoCollection<BsonDocument> bk = db.GetCollection<BsonDocument>("books");

            BsonDocument mybk = new BsonDocument {
                { "ID",textBox1.Text },
                {"Bname" , textBox2.Text}
        };
            bk.Insert(mybk);

         
        }

        private void Form2_Load(object sender, EventArgs e)
        {
           

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {MongoServer mongo = MongoServer.Create();
            mongo.Connect();
            MongoDatabase db;

            db = mongo.GetDatabase("Library");
         
        //    MongoCollection<BsonDocument> bk = db.GetCollection<BsonDocument>("books");
            MongoCollection<Info> bk =db.GetCollection<Info>("books");
            foreach (Info mybook in bk.Find(Query.EQ("ID", textBox1.Text)))
            {
                if (mybook.ID.Equals(textBox1.Text))
                {
                    IMongoUpdate update1 = new UpdateDocument();
                    if (textBox1.Text != "")
                    {
                        update1 = MongoDB.Driver.Builders.Update.Set("Bname", textBox2.Text);

                      
                    }
                    bk.Update(Query.EQ("ID", textBox1.Text), update1);

                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            MongoServer mongo = MongoServer.Create();
            mongo.Connect();
            MongoDatabase db;

            db = mongo.GetDatabase("Library");

            //    MongoCollection<BsonDocument> bk = db.GetCollection<BsonDocument>("books");
            MongoCollection<Info> bk = db.GetCollection<Info>("books");
            foreach (Info mybook in bk.Find(Query.EQ("ID", textBox1.Text)))
            {
                if (mybook.ID.Equals(textBox1.Text))
                {
                   bk.Remove(Query.EQ("ID",textBox1.Text));

                }
            }

        }
    }
}
