﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MongoDB.Bson;
using MongoDB.Driver;


namespace myapp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MongoServer mongo = MongoServer.Create();
            mongo.Connect();
            MongoDatabase db;

            db = mongo.GetDatabase("Library");
            var collection = db.GetCollection("books");

            var query = new QueryDocument("ID", textBox1.Text);

            MessageBox.Show("hi");
            foreach (BsonDocument item in collection.Find(query))
            {
                BsonElement id = item.GetElement("ID");
                BsonElement bookname = item.GetElement("Bname");
                textBox2.Text = bookname.ToString();
                MessageBox.Show("inforeach");


            }
            mongo.Disconnect();

            //collection.Insert(
        }

        private void button2_Click(object sender, EventArgs e) //insert
        {
            MongoServer mongo = MongoServer.Create();
            mongo.Connect();
            MongoDatabase db;

            db = mongo.GetDatabase("Library");
            MongoCollection<BsonDocument> persons = db.GetCollection<BsonDocument>("books");
            BsonDocument person = new BsonDocument {
                { "ID",textBox1.Text },
                {"Bname" , textBox2.Text}
        };
            persons.Insert(person);
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            MongoServer mongo = MongoServer.Create();
            mongo.Connect();
            MongoDatabase db;

            db = mongo.GetDatabase("Library");

            // var collectionEmployee = db.GetCollection("stud");//Gets Employee Collection
            // var lstEmployee = collectionEmployee.AsQueryable<Stud1>().ToList<Employee>(); //Queries the Employee collection and Converts to List            
            // dataGridView1.DataSource = lstEmployee;//Set the List as Data source  
            ////dataGridView1.da;//Binds the Grid
        }

        private void button3_Click(object sender, EventArgs e) //update
        {
        //    MongoServer mongo = MongoServer.Create();
        //    mongo.Connect();
        //    MongoDatabase db;

        //    db = mongo.GetDatabase("Library");

        //    MongoCollection<Info> Persons = myDB.GetCollection<Info>("persons");

        //    foreach (Info Aperson in Persons.Find(Query.EQ("personid", txtPersonId.Text)))
        //    {
        //        if (Aperson.personid.Equals(txtPersonId.Text))
        //        {
        //            IMongoUpdate update = new UpdateDocument();
        //            MongoCollection<BsonDocument> persons = db.GetCollection<BsonDocument>("books");
        //            BsonDocument person = new BsonDocument {
        //        { "ID",textBox1.Text },
        //        {"Bname" , textBox2.Text}
        //};
                  //  persons.Insert(person);



         
        }
    }
}