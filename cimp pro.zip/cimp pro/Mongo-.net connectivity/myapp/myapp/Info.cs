﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MongoDB.Bson;
//using MongoDB.Driver;

namespace myapp
{
    class Info
    {
       public ObjectId _id { get; set; }
            public string ID { get; set; }
            public string Bname { get; set; }
      
    }
}
