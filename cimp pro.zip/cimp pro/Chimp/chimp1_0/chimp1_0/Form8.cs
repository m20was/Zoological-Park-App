﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Builders;

namespace chimp1_0
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            try
            {
                MongoClient client = new MongoClient("mongodb://localhost");
                MongoServer server = client.GetServer();
                MongoDatabase db = server.GetDatabase("Zdata");
                MongoCursor<user> put = db.GetCollection<user>("dstaff").FindAll();

                foreach (user i in put)
                {

                    ListViewItem element = new ListViewItem(Convert.ToString(i.sid));
                    element.SubItems.Add(i.name);
                    element.SubItems.Add(i.username);
                    element.SubItems.Add(i.email);
                    element.SubItems.Add(i.mob_no);
                    element.SubItems.Add(i.gender);
                    element.SubItems.Add(i.Privilege);
                    listView1.Items.Add(element);
                    

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
           

        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label3_MouseHover(object sender, EventArgs e)
        {
            label3.BackColor = Color.Red;
        }

        private void label3_MouseLeave(object sender, EventArgs e)
        {
            label3.BackColor = Color.Gray;
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
