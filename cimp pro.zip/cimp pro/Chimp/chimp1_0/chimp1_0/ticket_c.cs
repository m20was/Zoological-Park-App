﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Bson;

namespace chimp1_0
{
    class ticket_c
    {
        public ObjectId _id { get; set; }
        public int t_id { get; set; }
        public string b_date { get; set; }
        public string v_date { get; set; }
        public string Name { get; set; }
        public string Mobile_no { get; set; }
        public Boolean cam { get; set; }
        public Boolean vcam { get; set; }
        public int no_member { get; set; }
        public int no_min { get; set; }
        public int donate { get; set; }
        public int amount { get; set; }
    }
}
