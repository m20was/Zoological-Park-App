﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace chimp1_0
{
    public partial class Form11 : Form
    {
        public Form11()
        {
            InitializeComponent();
        }
        int vq, mq;
        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                panel1.Show();
            }
            else
                panel1.Hide();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
                        panel2.Show();
            else
                panel2.Hide();
        }

        private void Form11_Load(object sender, EventArgs e)
        {
            panel1.Hide();
            panel2.Hide();
            label20.Text = DateTime.Now.ToString();
            textBox1.Text = "0"; 
            textBox2.Text = "0"; 
            textBox3.Text = "0" ;
            textBox4.Text = "0";
            textBox10.Text = "0";
            textBox11.Text = "0";
        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            String c1="", c2="", c3="";
            if (textBox1.Text != "0" || textBox2.Text != "0" || textBox3.Text != "0" || textBox4.Text != "0" )
            {
                int num1,num2,num3,num4;
                if (int.TryParse(textBox1.Text, out num1) && int.TryParse(textBox2.Text, out num2) && int.TryParse(textBox3.Text, out num3) && int.TryParse(textBox4.Text, out num4))
                {
                    MongoClient client = new MongoClient("mongodb://localhost");
                    MongoServer server = client.GetServer();
                    MongoDatabase db = server.GetDatabase("Zdata");
                    MongoCollection<BsonDocument> intk = db.GetCollection<BsonDocument>("Intake");
                    BsonDocument fund = new BsonDocument
            {
                {"Date",label20.Text},
                {"Gov_fund",Convert.ToInt32(textBox1.Text.Trim())},
                {"Donation",Convert.ToInt32(textBox2.Text.Trim())},
                {"Sponsors",Convert.ToInt32(textBox3.Text.Trim())},
                {"Spevent",Convert.ToInt32(textBox4.Text.Trim())}
                
                
            };

                    intk.Insert(fund);
                    c1 = "Intake. ";
                }
                else
                    MessageBox.Show("All field should contain a integer value");
            }
            if (comboBox1.Text != "" )
            {

                int mct=0, vct=0;
                if (checkBox1.Checked == false)
                {
                    mq = 0;
                    textBox10.Text = "0";
                }
                if (checkBox2.Checked == false)
                {
                    vq = 0;
                    textBox11.Text = "0";
                }
                
                
                if (int.TryParse(textBox10.Text, out mct) && int.TryParse(textBox11.Text, out vct) )
                {
                    MongoClient client = new MongoClient("mongodb://localhost");
                    MongoServer server = client.GetServer();
                    MongoDatabase db = server.GetDatabase("Zdata");
                    MongoCollection<BsonDocument> food = db.GetCollection<BsonDocument>("Fooddept");
                    BsonDocument stock = new BsonDocument
            {
                {"Date",label20.Text},
                {"stock",comboBox1.Text},
                {"MeatQ",mq},
                {"MeatC",mct},
                {"VegQ",vq},
                {"VegC",vct},

                
                
            };

                    food.Insert(stock);
                    c2 = "Food Dept. ";
                }
                else
                    MessageBox.Show("All field should contain a integer value");
            }
            if (textBox5.Text != "" || textBox12.Text != "" || textBox6.Text != "" || textBox7.Text != "" || textBox8.Text != "" || textBox9.Text != "")
            {
                int sc = 0, hc = 0, es = 0, tc = 0, ws = 0, exc = 0;
                if (int.TryParse(textBox5.Text, out sc) && int.TryParse(textBox12.Text, out hc) && int.TryParse(textBox12.Text, out hc) && int.TryParse(textBox6.Text, out es) && int.TryParse(textBox7.Text, out tc) && int.TryParse(textBox8.Text, out ws) && int.TryParse(textBox9.Text, out exc))

               {
               
                    MongoClient client = new MongoClient("mongodb://localhost");
                    MongoServer server = client.GetServer();
                    MongoDatabase db = server.GetDatabase("Zdata");
                    MongoCollection<BsonDocument> exp= db.GetCollection<BsonDocument>("expend");
                    BsonDocument amount = new BsonDocument
             {
                {"Date",label20.Text},
                {"Sanitation",sc},
                {"welding",checkBox3.Checked},
                {"plumbing",checkBox4.Checked},
                {"repair",checkBox6.Checked},
                {"spare",checkBox7.Checked},
                {"Hc",hc},
                {"es",es},
                {"tc",tc},
                {"ws",ws},
                {"exc",exc}


                
                
            };

                    exp.Insert(amount);
                    c3 = "Expenditure. ";
               }
              
                else
                    MessageBox.Show("Error while inserting Expenditure('All field must be Intiger')");
            }
            MessageBox.Show("Data got saved from("+c1+c2+c3+")");
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            mq = 1;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            mq = 10;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            mq = 20;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            mq = 40;
        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            vq = 1;
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            vq = 10;
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            vq = 20;
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            vq = 40;
        }

        private void label21_Click(object sender, EventArgs e)
        {
            Menuanim m = new Menuanim();
            m.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Close();
        }

        private void label21_MouseHover(object sender, EventArgs e)
        {
            label21.BackColor = Color.BurlyWood;
            label21.ForeColor = Color.DarkSlateGray;
        }

        private void label21_MouseLeave(object sender, EventArgs e)
        {
            label21.BackColor = Color.DarkSlateGray;
            label21.ForeColor = Color.BurlyWood;
        }
    }
}
