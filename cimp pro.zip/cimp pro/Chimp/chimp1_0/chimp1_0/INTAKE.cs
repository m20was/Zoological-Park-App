﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace chimp1_0
{
    public partial class INTAKE : Form
    {
        public INTAKE()
        {
            InitializeComponent();
        }
        int ig=0,id=0,isp=0,ise=0,it=0,pft=0;
        int js = 0, es = 0, exc = 0, hc = 0, ws = 0, ts = 0,ot=0,amount=0;
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void INTAKE_Load(object sender, EventArgs e)
        {
            search();
            cgen();
           panel1.Hide();
           it = it + amount;
           label5.Text = Convert.ToString(it);
           label6.Text = Convert.ToString(ot);
           label10.Text = Convert.ToString(it);
           label11.Text = Convert.ToString(ot);
           pft = it - ot;
           label7.Text = Convert.ToString(pft);
           label13.Text = Convert.ToString(amount);
           label15.Text = Convert.ToString(amount);
            if(pft>0)
            {
                label7.ForeColor = Color.SeaGreen;

            }
            else
                label7.ForeColor = Color.Maroon;
        }
        void cgen()
        {
            chart1.Series["Intake"].Points.AddXY("GOV_fund", ig);
            chart1.Series["Intake"].Points.AddXY("Donation", id);
            chart1.Series["Intake"].Points.AddXY("Sponsors", isp);
            chart1.Series["Intake"].Points.AddXY("Spevent", ise);
            chart1.Series["Intake"].Points.AddXY("Ticket", amount);
            
            chart1.Series["Total"].Points.AddXY("Total", it);


            chart2.Series["Outflow"].Points.AddXY("Sanitation", js);
            chart2.Series["Outflow"].Points.AddXY("Electric", es);
            chart2.Series["Outflow"].Points.AddXY("Hardware", hc);
            chart2.Series["Outflow"].Points.AddXY("Water", ws);
            chart2.Series["Outflow"].Points.AddXY("Transportation", ts);
            chart2.Series["Outflow"].Points.AddXY("Extras", exc);
           
            chart2.Series["Total"].Points.AddXY("Total", ot);
            chart3.Series["profit"].Points.AddXY("Inflow", it);
            chart3.Series["profit"].Points.AddXY("Outflow", ot);
            
           
        }
        void search()
        {
            listView1.Items.Clear();
            listView2.Items.Clear();

            int tot = 0;
            int toto = 0;
            try
            {
                MongoClient client = new MongoClient("mongodb://localhost");
                MongoServer server = client.GetServer();
                MongoDatabase db = server.GetDatabase("Zdata");
                MongoCursor<fund> put = db.GetCollection<fund>("Intake").FindAll();

                foreach (fund i in put)
                {

                    ListViewItem element = new ListViewItem(i.Date);
                    element.SubItems.Add(Convert.ToString(i.Gov_fund));
                    ig = ig + i.Gov_fund;
                    element.SubItems.Add(Convert.ToString(i.Donation));
                    id = id + i.Donation;
                    element.SubItems.Add(Convert.ToString(i.Sponsors));
                    isp = isp + i.Sponsors;
                    element.SubItems.Add(Convert.ToString(i.Spevent));
                    ise = ise + i.Spevent;
                    tot = i.Gov_fund + i.Donation + i.Sponsors + i.Spevent;
                    element.SubItems.Add(Convert.ToString(tot));
                    it = it + tot;
                    listView1.Items.Add(element);
                    


                }


                MongoCursor<fund> exp = db.GetCollection<fund>("expend").FindAll();
               
                foreach (fund i in exp)
                {

                    ListViewItem element = new ListViewItem(i.Date);
                    element.SubItems.Add(Convert.ToString(i.Sanitation));
                    js = js + i.Sanitation;
                    element.SubItems.Add(Convert.ToString(i.welding));
                    element.SubItems.Add(Convert.ToString(i.plumbing));
                    element.SubItems.Add(Convert.ToString(i.repair));
                    element.SubItems.Add(Convert.ToString(i.spare));
                    element.SubItems.Add(Convert.ToString(i.Hc));
                    hc = hc + i.Hc;
                    element.SubItems.Add(Convert.ToString(i.es));
                    es=es+i.es;
                    element.SubItems.Add(Convert.ToString(i.tc));
                    ts=ts+i.tc;
                    element.SubItems.Add(Convert.ToString(i.ws));
                    ws = ws + i.ws;
                    element.SubItems.Add(Convert.ToString(i.exc));
                    exc = exc + i.exc;
                    toto = i.Sanitation+ i.Hc + i.es + i.tc+i.ws+i.exc;
                    element.SubItems.Add(Convert.ToString(tot));
                    ot = ot + toto;
                    listView2.Items.Add(element);



                }
                MongoCursor<ticket_c> ticket = db.GetCollection<ticket_c>("Ticket_m").FindAll();

                foreach (ticket_c i in ticket)
                {

                    amount = amount + i.amount;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel1.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

    }
}
