﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using System.IO;

namespace chimp1_0
{
    public partial class Menuanim : Form
    {
        public Menuanim()
        {
            InitializeComponent();
        }
        Form10 f10 = new Form10();
        static public int mode= 1;
        int p = 0;
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            mode = 1;
            f10.Show();
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            mode = 2;
            f10.Show();
            this.Hide();
        }

        private void Menuanim_Load(object sender, EventArgs e)
        {
            panel1.Hide();
            label4.Hide();
            label5.Hide();
            label6.Hide();
            label7.Hide();
        }

        private void Menuanim_MouseHover(object sender, EventArgs e)
        {
           
        }

        private void Menuanim_MouseLeave(object sender, EventArgs e)
        {
            
        }

        
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (p ==0)
            {
                pictureBox3.BackColor = Color.LightBlue;
                this.BackColor = Color.LightBlue;
                p = 1;
                panel1.Show();

            }
            else
            {
                pictureBox3.BackColor = Color.LightYellow;
                this.BackColor = Color.Salmon;
                p = 0;
                panel1.Hide();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if(idcheck()==1)
            label2.Text = "Animal ID exists";
            else
            label2.Text = "Animal ID doesn't exists";
            
        }
       int  idcheck()
        {
            MongoClient client = new MongoClient("mongodb://localhost");
            MongoServer server = client.GetServer();
            MongoDatabase db = server.GetDatabase("Zdata");
            MongoCursor<anim> put = db.GetCollection<anim>("Animals").FindAll();

            foreach (anim i in put)
            {
                if (textBox1.Text == Convert.ToString(i.pid))
                {
                    return 1;

                }

            }
            return 0;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            

            if (idcheck() == 1)
            {

                MongoClient client = new MongoClient("mongodb://localhost");
                MongoServer server = client.GetServer();
                MongoDatabase db = server.GetDatabase("Zdata");
                MongoCollection<anim> anm = db.GetCollection<anim>("Animals");
                if (anm.Remove(Query.EQ("pid", Convert.ToInt32(textBox1.Text))).Ok == true)
                {
                    if (File.Exists(Form10.folder + textBox1.Text+".jpg"))
                    {
                        File.Delete(Form10.folder + textBox1.Text + ".jpg");
                    }
                    MessageBox.Show("Record successfully deleted!");
                }
                }
            else
                MessageBox.Show("Record Not Found");
        }

        private void pictureBox3_MouseHover(object sender, EventArgs e)
        {
            if (p != 1)
            {
                pictureBox3.BackColor = Color.DimGray;
                label6.Show();
            }
        }

        private void pictureBox3_MouseLeave(object sender, EventArgs e)
        {

            if (p != 1)
            {
                pictureBox3.BackColor = Color.LightYellow;
                label6.Hide();
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Form11 f11 = new Form11();
            f11.Show();
            this.Hide();
        }

        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {
            if (p != 1)
            {
                pictureBox1.BackColor = Color.DimGray;
                label4.Show();
            }
        }

        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
            if (p != 1)
            {
                pictureBox1.BackColor = Color.LightYellow;
                label4.Hide();
            }
        }

        private void pictureBox2_MouseHover(object sender, EventArgs e)
        {
            if (p != 1)
            {
                pictureBox2.BackColor = Color.DimGray;
                label5.Show();
            }
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            if (p != 1)
            {
                pictureBox2.BackColor = Color.LightYellow;
                label5.Hide();
            }
        }

        private void pictureBox4_MouseHover(object sender, EventArgs e)
        {
            if (p != 1)
            {
                pictureBox4.BackColor = Color.DimGray;
                label7.Show();
            }
        }

        private void pictureBox4_MouseLeave(object sender, EventArgs e)
        {
            if (p != 1)
            {
                pictureBox4.BackColor = Color.LightYellow;
                label7.Hide();
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
