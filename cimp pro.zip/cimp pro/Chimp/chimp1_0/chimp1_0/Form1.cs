﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Builders;

namespace chimp1_0
{
    public partial class Form1 : Form
    {
        public Form1()
        {

         //  Thread t1 = new Thread(new ThreadStart(splashs1));
          //  t1.Start();
          //  Thread.Sleep(3500);

            InitializeComponent();
           // t1.Abort();

            
         
        }
        
        
        Form3 f3 = new Form3();
        Form4 f4 = new Form4();
        

        public void splashs1()
        {
           // Application.Run(new Form2());
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label8.Text = DateTime.Now.ToString("d/MM/yyyy");
            img();
            label5.Hide();
            label7.Hide();
            label9.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
           
            f3.Show();
            this.Hide();
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {
            label2.Text = "Book a Ticket";
            pictureBox1.BackColor = Color.DeepSkyBlue;
            label5.Show();
        }

        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
            label2.Text = "";
            pictureBox1.BackColor = Color.Turquoise;
            label5.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (Form6.ap == 1)
            {
                f4.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("You are not an Admin.");
            }
           
        }

        private void pictureBox2_MouseHover(object sender, EventArgs e)
        {
            label2.Text = "Open Admin Panel";
            pictureBox2.BackColor = Color.DeepSkyBlue;
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            label2.Text = "";
            pictureBox2.BackColor = Color.Transparent;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            details d = new details();
            d.Show();
            this.Hide();
        }

        private int img()
        {
            
            try
            {
                MongoClient client = new MongoClient("mongodb://localhost");
                MongoServer server = client.GetServer();
                MongoDatabase db = server.GetDatabase("Zdata");
                MongoCursor<anim> put = db.GetCollection<anim>("Animals").FindAll();

                foreach (anim i in put)
                {

                   // if (System.IO.File.Exists(@"" + Form10.folder + Convert.ToString(i.pid) + ".jpg") == true)
                  //  pictureBox3.Image = Image.FromFile(@"" + Form10.folder +Convert.ToString(i.pid)+ ".jpg");
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            return 0;
        }

        private void pictureBox3_MouseHover(object sender, EventArgs e)
        {
            label2.Text = "Detail view";
            pictureBox3.BackColor = Color.DeepSkyBlue;
            label9.Show();
        }

        private void pictureBox3_MouseLeave(object sender, EventArgs e)
        {
            label2.Text = "";
            pictureBox3.BackColor = Color.RosyBrown;
            label9.Hide();
        }

        private void pictureBox5_MouseHover(object sender, EventArgs e)
        {
            label2.Text = "Zoo Entry";
            pictureBox5.BackColor = Color.DeepSkyBlue;
            label7.Show();
        }

        private void pictureBox5_MouseLeave(object sender, EventArgs e)
        {
            label2.Text = "";
            pictureBox5.BackColor = Color.LightSteelBlue;
            label7.Hide();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Menuanim m = new Menuanim();
            m.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Form6 f6 = new Form6();
            Form6.ap = 0;
            f6.Show();

            this.Hide();
        }

        private void label6_MouseHover(object sender, EventArgs e)
        {
            label6.ForeColor = Color.Olive;
        }

        private void label6_MouseLeave(object sender, EventArgs e)
        {
            label6.ForeColor = Color.RoyalBlue;

        }
        
       

     
    }
}
