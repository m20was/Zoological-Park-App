﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace chimp1_0
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void label9_MouseHover(object sender, EventArgs e)
        {
            label9.ForeColor = Color.DarkBlue;
        }

        private void label9_MouseLeave(object sender, EventArgs e)
        {
            label9.ForeColor = Color.Brown;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_MouseHover(object sender, EventArgs e)
        {
            label2.Text = "Add User";
            pictureBox2.BackColor = Color.SteelBlue;
        }

        private void pictureBox3_MouseHover(object sender, EventArgs e)
        {
            label3.Text = "Update";
            pictureBox3.BackColor = Color.SteelBlue;
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_MouseHover(object sender, EventArgs e)
        {
            label4.Text = "Delete";
            pictureBox4.BackColor = Color.SteelBlue;
        }

        private void pictureBox5_MouseHover(object sender, EventArgs e)
        {
            label5.Text = "Search";
            pictureBox5.BackColor = Color.SteelBlue;
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            label2.Text = "";
            pictureBox2.BackColor = Color.LightSteelBlue;
        }

        private void pictureBox3_MouseLeave(object sender, EventArgs e)
        {
            label3.Text = "";
            pictureBox3.BackColor = Color.LightSeaGreen;
        }

        private void pictureBox4_MouseLeave(object sender, EventArgs e)
        {
            label4.Text = "";
            pictureBox4.BackColor = Color.BurlyWood;
        }

        private void pictureBox5_MouseLeave(object sender, EventArgs e)
        {
            label5.Text = "";
            pictureBox5.BackColor = Color.Thistle;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Form7 f7 = new Form7();
            Form6.op = 1;
            f7.Show();
            
           
        }

        private void label6_MouseHover(object sender, EventArgs e)
        {
            label6.ForeColor = Color.Brown;
        }

        private void label6_MouseLeave(object sender, EventArgs e)
        {
            label6.ForeColor = Color.RoyalBlue;
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Form6 f6 = new Form6();
            f6.Show();
            this.Close();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Form7 f7 = new Form7();
            Form6.op = 2;
            f7.Show();
            
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Form5 f5 = new Form5();
            f5.Show();

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Form8 f8 =new Form8();
            f8.Show();
        }
    }
}
