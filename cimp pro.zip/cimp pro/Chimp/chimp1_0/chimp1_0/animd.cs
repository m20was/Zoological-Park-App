﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Builders;

namespace chimp1_0
{
    public partial class animd : Form
    {
        public animd()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            show();
        }
        int show()
        {

            if (textBox1.Text != "")
            {

                MongoClient client = new MongoClient("mongodb://localhost");
                MongoServer server = client.GetServer();
                MongoDatabase db = server.GetDatabase("Zdata");
                MongoCursor<anim> put = db.GetCollection<anim>("Animals").FindAll();

                foreach (anim i in put)
                {
                    if (textBox1.Text == Convert.ToString(i.pid))
                    {
                        label2.Text = Convert.ToString(i.pid);
                        pictureBox1.Image = Image.FromFile(@"E:\database\img\" + Convert.ToString(i.pid) + ".jpg");
                        label4.Text = i.animal;
                        label5.Text = i.category;
                        label7.Text = i.gender;
                        int age =  DateTime.Now.Year-Convert.ToDateTime(i.DoB).Year;
                        label9.Text = age.ToString();
                        label11.Text = i.species;
                        label13.Text = i.location;
                        label15.Text = i.origin;
                        return 1;
                    }
                }




                
            }
                return 0;
            
        }

        private void animd_Load(object sender, EventArgs e)
        {
            
            if (Form10.sh == 1)
            {
                textBox1.Text = Convert.ToString(Form10.id);
                show();
               
                button3.Hide();
            }
            else
            {
                textBox1.Text = "";

            }
            label18.Hide();
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Form10.sh == 1)
            {
                Form10 f10 = new Form10();
                f10.Show();
                Form10.sh = 0;
                this.Close();
            }
            else
            {

                details d = new details();
                d.Show();
                this.Close();
            }

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
                            if(show()==0)
                            {

                            label2.Text = "";
                            pictureBox1.Image = null;
                            label4.Text = "";
                            label5.Text = "";
                            label7.Text = "";
                            label9.Text = "";
                            label11.Text = "";
                            label13.Text = "";
                            label15.Text = "";
                            label18.Show();
                            }
                            else
                                label18.Hide();
        }
    }
}
