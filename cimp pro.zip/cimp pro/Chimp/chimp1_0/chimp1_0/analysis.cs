﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace chimp1_0
{
    public partial class analysis : Form
    {
        public analysis()
        {
            InitializeComponent();
        }

        int mt = 0, vt=0,mq=0,vq=0;
        
        private void analysis_Load(object sender, EventArgs e)
        {
            mt = 0; vt = 0; mq = 0; vq = 0;
            int ft=0;
            search();
            cgen();
            ft=mt+vt;
            label3.Text = Convert.ToString("Rs."+ft);
            label8.Text = Convert.ToString(mq +" T");
            label9.Text = Convert.ToString(vq + " T");
            label10.Text = Convert.ToString("Rs."+mt);
            label11.Text = Convert.ToString("Rs." +vt);
        }
        void cgen()
        {
            chart1.Series["Food"].Points.AddXY("Meat", mq);
            chart1.Series["Food"].Points.AddXY("Veg", vq);
            chart2.Series["Foodc"].Points.AddXY("Meat",mt);
            chart2.Series["Foodc"].Points.AddXY("Veg", vt);
        }
        void search()
        {
            listView1.Items.Clear();

            int tot = 0;
            try
            {
                MongoClient client = new MongoClient("mongodb://localhost");
                MongoServer server = client.GetServer();
                MongoDatabase db = server.GetDatabase("Zdata");
                MongoCursor<fund> put = db.GetCollection<fund>("Fooddept").FindAll();

                foreach (fund i in put)
                {

                    ListViewItem element = new ListViewItem(i.Date);
                    element.SubItems.Add(i.stock);
                    element.SubItems.Add(Convert.ToString(i.MeatQ));
                    element.SubItems.Add(Convert.ToString(i.MeatC));
                    element.SubItems.Add(Convert.ToString(i.VegQ));
                    element.SubItems.Add(Convert.ToString(i.VegC));
                    tot = i.MeatQ * i.MeatC + i.VegQ * i.VegC;
                    element.SubItems.Add(Convert.ToString(tot));

                    listView1.Items.Add(element);
                    mt = mt + i.MeatC*i.MeatQ;
                    vt = vt + i.VegC * i.VegQ;
                    mq = mq + i.MeatQ;
                    vq = vq + i.VegQ;

                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Close();
        }

        private void chart2_Click(object sender, EventArgs e)
        {

        }
    }
}
