﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace chimp1_0
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }
       static public string folder = @"C:\Users\User\Documents\";
       // static public string sfolder = System.IO.Path.Combine(folder, "Chimp_img");
       //System.IO.Directory.CreateDirectory(sfolder,System.Security.AccessControl.allo);
        OpenFileDialog opn=new OpenFileDialog();
        private void button1_Click(object sender, EventArgs e)
        {
                opn.Filter="*.png|*.jpg";
            if(opn.ShowDialog()== DialogResult.OK)
            {
                textBox1.Text = opn.FileName;
                textBox2.Text = opn.SafeFileName;

                pictureBox1.Image = Image.FromFile(@"" + opn.FileName);
                System.IO.File.Copy(opn.FileName, folder+opn.SafeFileName, true);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form9_Load(object sender, EventArgs e)
        {

        }
    }
}
