﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Builders;

namespace chimp1_0
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }
       static public int ap = 0;
       static public int op = 0;

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            int a = ucheck();
            if (a == 1)
            {
                if (checkBox1.Checked && ap == 1)
                {
                    Form4 f4 = new Form4();
                    f4.Show();
                    this.Hide();

                }
                else if (checkBox1.Checked)
                {
                    MessageBox.Show("You are not an Admin.");
                }
                else
                {
                    Form1 f1 = new Form1();
                    f1.Show();
                    this.Hide();

                }

            }
            else
                MessageBox.Show("Invalid Username or Password.");
        }


        public int ucheck()
        {
            try
            {
                MongoClient client = new MongoClient("mongodb://localhost");
                MongoServer server = client.GetServer();
                MongoDatabase db = server.GetDatabase("Zdata");
                MongoCursor<user> put = db.GetCollection<user>("dstaff").FindAll();

                foreach (user i in put)
                {
                    if (textBox1.Text == Convert.ToString(i.username) && textBox2.Text == Convert.ToString(i.password))
                    {
                        if (i.Privilege == "A" || i.Privilege == "M")
                           ap = 1;
                        return 1;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            return 0;
        }


        private void label3_MouseHover(object sender, EventArgs e)
        {
            label3.ForeColor = Color.Red;
            label3.BackColor = Color.SteelBlue;
        }

        private void label3_MouseLeave(object sender, EventArgs e)
        {
            label3.ForeColor = Color.Black;
            label3.BackColor = Color.Transparent;
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            ap = 0;
            op = 0;
            Form7 f7 = new Form7();
            Form5 f5 = new Form5();
            Form4 f4 = new Form4();
            f7.Close();
            f5.Close();
            f4.Close();
        }
    }
}
