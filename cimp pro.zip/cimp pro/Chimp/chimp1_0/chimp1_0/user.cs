﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Bson;


namespace chimp1_0
{
    class user
    {
        public ObjectId _id { get; set; }

        public int sid {get; set;}
        public string name { get; set; }
        public string username { get; set; }
        public string email { get; set; }
        public string gender { get; set; }
        public string password { get; set; }
        public string mob_no { get; set; }
        public string Privilege { get; set; }

   
    }
}
