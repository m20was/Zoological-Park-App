﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Bson;

namespace chimp1_0
{
    class anim
    {
        public ObjectId _id { get; set; }
        public int pid { get; set; }
         public string category  { get; set; }
        public string animal { get; set; }
        public string species { get; set; }
        public string gender { get; set; }
        public string DoB { get; set; }
        public string captivity { get; set; }
        public string health { get; set; }
        public string csstatus { get; set; }
        public string location { get; set; }
        public string origin { get; set; }
        public string parent_id { get; set; }

                

    }
}
