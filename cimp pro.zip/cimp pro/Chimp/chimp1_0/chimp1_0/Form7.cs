﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using System.Text.RegularExpressions;

namespace chimp1_0
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }
        public string pos = "s";
        public string gnd = "m";
        public int sno = 000;

        private void label9_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.Hide();
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }
     

      

      

     

        private void label6_Click(object sender, EventArgs e)
        {
            Form6 f6=new Form6();
            Form6.ap = 0;
            f6.Show();
           
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Form7_Load(object sender, EventArgs e)
        {
            search();
            label3.Text = Convert.ToString(sno+1);
            label14.Hide();
            button1.Hide();
            button2.Hide();
            if(Form6.op==0)
            {
                button1.Show();
                button2.Show();
                
            }
            else if (Form6.op == 1)
            {
                button1.Show();
                label1.Text = "Add user";
            }
            else if (Form6.op == 2)
            {
                button2.Show();
                label1.Text = "Update User";
                label16.Text = "Enter Username of user to be updated";
            }
        }


        private void search()
        {
            
            sno = 0;
            try
            {
                MongoClient client = new MongoClient("mongodb://localhost");
                MongoServer server = client.GetServer();
                MongoDatabase db = server.GetDatabase("Zdata");
                MongoCursor<user> put = db.GetCollection<user>("dstaff").FindAll();

                foreach (user i in put)
                {

                    sno = i.sid;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            if (textBox4.Text == textBox5.Text)
            {
                label14.Text = "Password Matched";
                label14.ForeColor = Color.Green;
                label14.Show();

            }
            else
            {
                label14.Text = "Password Doesn't Match";
                label14.ForeColor = Color.Red;
                label14.Show();
            }
               
        }

        private void button1_Click(object sender, EventArgs e)
        {
            search();
            int mob;
            label3.Text = Convert.ToString(sno + 1);
            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
        Match match = regex.Match(textBox3.Text);
           if(textBox1.Text !="" && textBox2.Text !="" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "" && textBox6.Text!="" )
           {
               if (textBox1.Text.All(char.IsLetter))
               {
                   if (match.Success)
                   { 
                   if (textBox4.Text == textBox5.Text)
                   {
                       if (ucheck(textBox2.Text) != 1)
                       {
                           if (int.TryParse(textBox6.Text, out mob)&& textBox3.Text.Length==10)
                           {
                               MongoClient client = new MongoClient("mongodb://localhost");
                               MongoServer server = client.GetServer();
                               MongoDatabase db = server.GetDatabase("Zdata");
                               MongoCollection<BsonDocument> staff = db.GetCollection<BsonDocument>("dstaff");
                               BsonDocument member = new BsonDocument
            {
                 {"sid",sno+1},   
                 {"name",textBox1.Text.Trim()},
                {"username",textBox2.Text.Trim()},
                {"email",textBox3.Text.Trim()},
                {"gender",gnd},
                {"password",textBox4.Text.Trim()},
                {"mob_no",textBox6.Text.Trim()},
                {"Privilege",pos}
            };
                               staff.Insert(member);
                               MessageBox.Show(textBox1.Text + " Got added");
                           }
                           else
                               MessageBox.Show("Mobile No. must be in digits & have a valid length");
                       }
                       else
                           MessageBox.Show("User already exists");

                   }
                   else
                   {
                       MessageBox.Show("Password and Confirm Password does not match.");
                   }
                   }
                       else
                       MessageBox.Show("Email is not valid");
               }
               else
                   MessageBox.Show("Only letters are allowed in Name field");
           }
           else
           {
               MessageBox.Show("All fields are required.");
           }
           search();
           label3.Text = Convert.ToString(sno+1);
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            gnd = "f";
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            gnd = "m";
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Admin")
            {
                pos = "A";
            }
            else if (comboBox1.Text == "Manager")
            {
                pos = "M";
            }
            else
                pos = "s";

        }

        private void label6_MouseHover(object sender, EventArgs e)
        {
            label6.ForeColor = Color.Olive;
        }

        private void label6_MouseLeave(object sender, EventArgs e)
        {

            label6.ForeColor = Color.RoyalBlue;
        }

        private void label9_MouseHover_1(object sender, EventArgs e)
        {
            label9.ForeColor = Color.DarkBlue;
        }

        private void label9_MouseLeave(object sender, EventArgs e)
        {
            label9.ForeColor = Color.Brown;
        }


        public int ucheck(string u)
        {
            try
            {
                MongoClient client = new MongoClient("mongodb://localhost");
                MongoServer server = client.GetServer();
                MongoDatabase db = server.GetDatabase("Zdata");
                MongoCursor<user> put = db.GetCollection<user>("dstaff").FindAll();

                foreach (user i in put)
                {
                    if (u == Convert.ToString(i.username))
                    {
                       
                            return 1;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            return 0;
        }



        private void button2_Click(object sender, EventArgs e)
        {
            int mob=0;
           if(ucheck(textBox2.Text)==1)
               if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "" && textBox6.Text != "")
               {
                   Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
                   Match match = regex.Match(textBox3.Text);
                   if (textBox1.Text.All(char.IsLetter))
                   {
                        if (match.Success)
                   { 
                       if (textBox4.Text == textBox5.Text)
                       {
                           if (int.TryParse(textBox6.Text, out mob)&& textBox6.Text.Length==10)
                           {
                               MongoClient client = new MongoClient("mongodb://localhost");
                               MongoServer server = client.GetServer();
                               MongoDatabase db = server.GetDatabase("Zdata");
                               MongoCollection<user> staff = db.GetCollection<user>("dstaff");
                               foreach (user i in staff.Find(Query.EQ("username", textBox2.Text.Trim())))
                               {
                                   IMongoUpdate update1 = new UpdateDocument();
                                   IMongoUpdate update2 = new UpdateDocument();
                                   IMongoUpdate update3 = new UpdateDocument();
                                   IMongoUpdate update4 = new UpdateDocument();
                                   IMongoUpdate update5 = new UpdateDocument();
                                   IMongoUpdate update6 = new UpdateDocument();

                                   if (textBox2.Text != "")
                                   {
                                       update1 = MongoDB.Driver.Builders.Update.Set("name", textBox1.Text);
                                       update2 = MongoDB.Driver.Builders.Update.Set("email", (textBox3.Text));
                                       update3 = MongoDB.Driver.Builders.Update.Set("gender", gnd);
                                       update4 = MongoDB.Driver.Builders.Update.Set("password", textBox4.Text);
                                       update5 = MongoDB.Driver.Builders.Update.Set("Privilege", pos);
                                       update6 = MongoDB.Driver.Builders.Update.Set("mob_no", textBox6.Text);


                                   }
                                   staff.Update(Query.EQ("username", (textBox2.Text)), update1);
                                   staff.Update(Query.EQ("username", (textBox2.Text)), update2);
                                   staff.Update(Query.EQ("username", (textBox2.Text)), update3);
                                   staff.Update(Query.EQ("username", (textBox2.Text)), update4);
                                   staff.Update(Query.EQ("username", (textBox2.Text)), update5);
                                   staff.Update(Query.EQ("username", textBox2.Text), update6);
                                   MessageBox.Show("Updated");
                                   //  refresh();
                                   break;
                               }
                           }
                           else
                               MessageBox.Show("Mobile No.is not valid");
                       }
                       else
                       {
                           MessageBox.Show("Password and Confirm Password does not match.");
                       }
                   }
                   else
                   {
                       MessageBox.Show("All fields are required.");
                   }
                   }
                   else
                       MessageBox.Show("Email is not valid");
               }
               else
                   MessageBox.Show("Only letters are allowed in Name field");
           else
           {
               MessageBox.Show("User not found");

           }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
               
                if(Form6.op == 2)
                {

                    label15.Text = "User doesn't exists";
                    MongoClient client = new MongoClient("mongodb://localhost");
                    MongoServer server = client.GetServer();
                    MongoDatabase db = server.GetDatabase("Zdata");
                    MongoCursor<user> put = db.GetCollection<user>("dstaff").FindAll();

                    foreach (user i in put)
                    {
                        if (textBox2.Text == Convert.ToString(i.username))
                        {
                            label15.Text = "User exists";
                            label3.Text = Convert.ToString(i.sid);
                            textBox1.Text=i.name;
                            textBox3.Text=i.email;
                            textBox3.Text = i.email;
                            textBox6.Text = i.mob_no;
                            if (i.gender == "m")
                                radioButton1.Checked = true;
                            else
                                radioButton2.Checked = true;

                          

                           
                        }

                    }


                }


   
                
        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

  
    }

}
