﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Builders;

namespace chimp1_0
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        string v_date = DateTime.Now.ToString("d/MM/yyyy");
        int no_mbr = 1;
        int no_min = 0;
        int camount = 0;
        int amount=50;
        int donate = 0;
        int count = 0;

       
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown1.Hide();
            numericUpDown2.Hide();
            label14.Hide();
            no_mbr = 1;
            no_min = 0;
            amount_up();
            
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
           numericUpDown1.Show();
           numericUpDown2.Show();
           numericUpDown1.Value = 1;
            numericUpDown2.Value = 0;
            label14.Show();
            no_mbr =Convert.ToInt32(numericUpDown1.Value);
            no_min = Convert.ToInt32(numericUpDown2.Value);
            amount_up();
            
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

            if (checkBox2.Checked)
            {
                textBox3.Show();
                textBox3.Text = "100";
                    donate = Convert.ToInt32(textBox3.Text);
               
            }
            else
            {
                textBox3.Hide();
                donate = 0;
                
            
            }
            amount_up();

        }

      

        private void Form3_Load(object sender, EventArgs e)
        {
           numericUpDown1.Hide();
           numericUpDown2.Hide();
           search();
           
            dateTimePicker1.Hide();
            label8.Text = DateTime.Now.ToString("d/MM/yyyy");
            textBox3.Hide();
            label14.Hide();
            label12.Text = "50";
            amount_up();
           
       
           
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label9_MouseHover(object sender, EventArgs e)
        {
            label9.ForeColor = Color.DarkBlue;
        }

        private void label9_MouseLeave(object sender, EventArgs e)
        {

            label9.ForeColor = Color.Brown;
        }

        private void label9_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox4.Checked)
                dateTimePicker1.Show();
            else
                dateTimePicker1.Hide();
        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {int mob;
            search();
            if (textBox1.Text.All(char.IsLetter))
            {
                if (int.TryParse(textBox2.Text, out mob)&&textBox2.Text.Length==10)
                {
                    MongoClient client = new MongoClient("mongodb://localhost");
                    MongoServer server = client.GetServer();
                    MongoDatabase db = server.GetDatabase("Zdata");
                    MongoCollection<BsonDocument> tm = db.GetCollection<BsonDocument>("Ticket_m");
                    BsonDocument tbook = new BsonDocument
            {
                {"t_id", Convert.ToInt32(label13.Text)},
                {"b_date",label8.Text},
                {"v_date",v_date},
                {"Name",textBox1.Text},
                {"Mobile_no",textBox2.Text},
                {"cam",checkBox1.Checked},
                {"vcam",checkBox3.Checked},
                {"no_member",no_mbr},
                {"no_min",no_min},
                {"donate",donate},
                {"amount",amount}
                
            };

                    tm.Insert(tbook);
                    MessageBox.Show(textBox1.Text + "'Ticket Got Booked");
                    search();
                }
                else
                    MessageBox.Show("Mobile No. must be in digits and have length of 10");
            }
            else
                MessageBox.Show("Name must only contain Letter");

        }
           private void search()
        {
            
            count = 0;
            try
            {
                MongoClient client = new MongoClient("mongodb://localhost");
                MongoServer server = client.GetServer();
                MongoDatabase db = server.GetDatabase("Zdata");
                MongoCursor<ticket_c> put = db.GetCollection<ticket_c>("Ticket_m").FindAll();

                foreach (ticket_c i in put)
                {
                    count = i.t_id;
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            label13.Text = Convert.ToString(count + 1);
      }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
                camount = camount + 50;
            else
                camount = camount - 50;

            amount_up();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked==true)
                camount = camount + 100;
            else
                camount = camount - 100;

            amount_up();
        }

        void amount_up()
        {
            amount = (no_min*25)+(no_mbr-no_min)*50 + camount + donate;
            label12.Text = Convert.ToString(amount);

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            int donate1 = 100;
            if (checkBox2.Checked == true  && int.TryParse(textBox3.Text, out donate1))
                donate = donate1;
            else 
                textBox3.Text = "100";

           amount_up();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            amount_up();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

    
        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            if (numericUpDown1.Value >= numericUpDown2.Value)
            {
                no_mbr = Convert.ToInt32(numericUpDown1.Value);

            }
            else
            {
                numericUpDown1.Value = Convert.ToDecimal(no_min);
                //MessageBox.Show("Wrong value in Group field");
                no_mbr = Convert.ToInt32(numericUpDown1.Value);
                

            }

           amount_up();
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            no_min = Convert.ToInt32(numericUpDown2.Value);
            if (no_min > no_mbr)
            {
               numericUpDown1.Value = numericUpDown1.Value + 1;
               //no_mbr =Convert.ToInt32(numericUpDown1.Value);
            }
            
            amount_up();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
