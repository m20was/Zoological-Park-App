using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using System.IO;
using System.Diagnostics;
using System.Globalization;

namespace chimp1_0
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
        }
        string gnd = "m";
        public int count = 0;
        static public string folder = @"E:\database\img\";
        static public int sh = 0;
        static public int id = 0;
        OpenFileDialog opn = new OpenFileDialog();

        private void Form10_Load(object sender, EventArgs e)
        {
            button3.Hide();

            search();
            textBox1.Text = Convert.ToString(count + 1);
            button1.Hide();
            button2.Hide();
            if (Menuanim.mode == 1)
                button1.Show();
            else
            {
                button2.Show();
                //panel1.Hide();

            }
            label18.Hide();
            textBox2.Hide();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            gnd = "Female";
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0 && Menuanim.mode == 2 && checkBox1.Checked != true)
            {
                string lsid = listView1.SelectedItems[0].Text;

                textBox1.Text = lsid;
                label16.Text = "Id  Exists";

            }
            if (checkBox1.Checked == true)
            {
                if (listView1.SelectedItems.Count > 0)
                {
                    string lsid = listView1.SelectedItems[0].Text;

                    textBox2.Text = lsid;


                }

            }




        }

        private void button4_Click(object sender, EventArgs e)
        {
            search();

        }

        private void search()
        {
            listView1.Items.Clear();
            count = 0;
            try
            {
                MongoClient client = new MongoClient("mongodb://localhost");
                MongoServer server = client.GetServer();
                MongoDatabase db = server.GetDatabase("Zdata");
                MongoCursor<anim> put = db.GetCollection<anim>("Animals").FindAll();

                foreach (anim i in put)
                {

                    ListViewItem element = new ListViewItem(Convert.ToString(i.pid));
                    element.SubItems.Add(i.category);
                    element.SubItems.Add(i.animal);
                    element.SubItems.Add(i.species);
                    element.SubItems.Add(i.gender);
                    int age =  DateTime.Now.Year-Convert.ToDateTime(i.DoB).Year;
                    element.SubItems.Add(age.ToString());
                    element.SubItems.Add(i.captivity);
                    element.SubItems.Add(i.health);
                    element.SubItems.Add(i.location);
                    element.SubItems.Add(i.origin);

                    listView1.Items.Add(element);

                    count = i.pid;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
                textBox2.Text = "";
            if (icheck(Convert.ToInt32(textBox1.Text)) == 0)
            {
                if (textBox1.Text != "" && textBox3.Text != "" && textBox4.Text != "" && comboBox2.Text != "" && textBox7.Text != "" && textBox8.Text != "" && comboBox1.Text != "" && textBox1.Text != "" && textBox1.Text != "")
                {
                    if (textBox3.Text.All(char.IsLetter) && textBox4.Text.All(char.IsLetter) && textBox10.Text.All(char.IsLetter))
                    {
                        MongoClient client = new MongoClient("mongodb://localhost");
                        MongoServer server = client.GetServer();
                        MongoDatabase db = server.GetDatabase("Zdata");
                        MongoCollection<BsonDocument> animal = db.GetCollection<BsonDocument>("Animals");
                        BsonDocument member = new BsonDocument
            {
                {"pid",Convert.ToInt32(textBox1.Text.Trim())},
                {"category",comboBox1.Text},
                {"animal",textBox3.Text.Trim()},
                {"species",textBox4.Text.Trim()},
                {"gender",gnd},
                {"DoB",dateTimePicker1.Text.ToString()},
                {"captivity",comboBox2.Text},
                {"health",textBox7.Text.Trim()},
                {"csstatus",textBox8.Text.Trim()},
                {"location",textBox9.Text.Trim()},
                {"origin",textBox10.Text.Trim()},
                {"parent_id",textBox2.Text.Trim()}
                
            };

                        animal.Insert(member);
                        MessageBox.Show(textBox1.Text + " Got added");
                        search();
                        button3.Show();
                        if (textBox11.Text != "")
                        {
                            System.IO.File.Copy(opn.FileName, (folder + Convert.ToString(count) + ".jpg"), true);
                        }
                        id = count;
                        sh = 1;

                        animd a = new animd();
                        a.Show();
                        this.Hide();


                    }
                    else
                        MessageBox.Show("Animal name and species and Orgin must be in letters");
                }
                else
                    MessageBox.Show("All fields are required");
            }
            else
            {
                MessageBox.Show("Id already exist");
                search();
                textBox1.Text = Convert.ToString(count + 1);

            }
            search();
            textBox1.Text = Convert.ToString(count + 1);

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            gnd = "Male";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            opn.Filter = "*.png|*.jpg";
            if (opn.ShowDialog() == DialogResult.OK)
            {
                textBox11.Text = opn.FileName;
                textBox12.Text = opn.SafeFileName;
                System.IO.FileStream fs = new System.IO.FileStream(opn.FileName, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                pictureBox1.Image = System.Drawing.Image.FromStream(fs);//Image.FromFile(@"" + opn.FileName);
               
                fs.Dispose();
                fs.Close();
            }
        }
        public int icheck(int u)
        {
            try
            {
                MongoClient client = new MongoClient("mongodb://localhost");
                MongoServer server = client.GetServer();
                MongoDatabase db = server.GetDatabase("Zdata");
                MongoCursor<anim> put = db.GetCollection<anim>("Animals").FindAll();

                foreach (anim i in put)
                {
                    if (u == i.pid)
                    {

                        return 1;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            return 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
                textBox2.Text = "0";
            if (textBox1.Text != "" && textBox3.Text != "" && textBox4.Text != "" && comboBox2.Text != "" && textBox7.Text != "" && textBox8.Text != "" && comboBox1.Text != "" && textBox1.Text != "" && textBox1.Text != "")
            {
                if (textBox3.Text.All(char.IsLetter) && textBox4.Text.All(char.IsLetter) && textBox10.Text.All(char.IsLetter))
                    {
                MongoClient client = new MongoClient("mongodb://localhost");
                MongoServer server = client.GetServer();
                MongoDatabase db = server.GetDatabase("Zdata");
                MongoCollection<anim> anim1 = db.GetCollection<anim>("Animals");
                foreach (anim i in anim1.Find(Query.EQ("pid", Convert.ToInt32(textBox1.Text.Trim()))))
                {
                    IMongoUpdate update1 = new UpdateDocument();
                    IMongoUpdate update2 = new UpdateDocument();
                    IMongoUpdate update3 = new UpdateDocument();
                    IMongoUpdate update4 = new UpdateDocument();
                    IMongoUpdate update5 = new UpdateDocument();
                    IMongoUpdate update6 = new UpdateDocument();
                    IMongoUpdate update7 = new UpdateDocument();
                    IMongoUpdate update8 = new UpdateDocument();

                    IMongoUpdate update10 = new UpdateDocument();
                    IMongoUpdate update11 = new UpdateDocument();
                    IMongoUpdate update12 = new UpdateDocument();
                    if (textBox1.Text != "")
                    {
                        update1 = MongoDB.Driver.Builders.Update.Set("category", comboBox1.Text);
                        update2 = MongoDB.Driver.Builders.Update.Set("animal", (textBox3.Text));
                        update3 = MongoDB.Driver.Builders.Update.Set("species", textBox4.Text);
                        update4 = MongoDB.Driver.Builders.Update.Set("gender", gnd);
                        update5 = MongoDB.Driver.Builders.Update.Set("DoB", dateTimePicker1.Text.ToString());
                        update6 = MongoDB.Driver.Builders.Update.Set("captivity", comboBox2.Text);
                        update7 = MongoDB.Driver.Builders.Update.Set("health", textBox7.Text.Trim());
                        update8 = MongoDB.Driver.Builders.Update.Set("csstatus", textBox8.Text.Trim());
                        update10 = MongoDB.Driver.Builders.Update.Set("location", textBox9.Text.Trim());
                        update11 = MongoDB.Driver.Builders.Update.Set("origin", textBox10.Text.Trim());
                        update12 = MongoDB.Driver.Builders.Update.Set("parent_id", textBox2.Text.Trim());

                    }
                    anim1.Update(Query.EQ("pid", Convert.ToInt32(textBox1.Text.Trim())), update1);
                    anim1.Update(Query.EQ("pid", Convert.ToInt32(textBox1.Text.Trim())), update2);
                    anim1.Update(Query.EQ("pid", Convert.ToInt32(textBox1.Text.Trim())), update3);
                    anim1.Update(Query.EQ("pid", Convert.ToInt32(textBox1.Text.Trim())), update4);
                    anim1.Update(Query.EQ("pid", Convert.ToInt32(textBox1.Text.Trim())), update5);
                    anim1.Update(Query.EQ("pid", Convert.ToInt32(textBox1.Text.Trim())), update6);
                    anim1.Update(Query.EQ("pid", Convert.ToInt32(textBox1.Text.Trim())), update7);
                    anim1.Update(Query.EQ("pid", Convert.ToInt32(textBox1.Text.Trim())), update8);
                    anim1.Update(Query.EQ("pid", Convert.ToInt32(textBox1.Text.Trim())), update10);
                    anim1.Update(Query.EQ("pid", Convert.ToInt32(textBox1.Text.Trim())), update11);
                    anim1.Update(Query.EQ("pid", Convert.ToInt32(textBox1.Text.Trim())), update12);
                    if (textBox11.Text != "")
                    {

                        if (File.Exists(folder + textBox1.Text + ".jpg"))
                        {
                            File.Delete(folder + Convert.ToString(i.pid) + ".jpg");
                        }
                        System.IO.File.Copy(opn.FileName, (folder + i.pid + ".jpg"), true);

                    }


                    MessageBox.Show("Updated");
                    Form10 f10 = new Form10();
                    f10.Show();
                    this.Close();

                    //  refresh();
                    break;
                }

                    }
                else
                    MessageBox.Show("Animal name and species and Orgin must be in letters");
            }
            else
                MessageBox.Show("All fields are required");



        }

        private void label15_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile("E:/cimp pro/1472769717_5373_-_WWF.png");
            try
            {
                MongoClient client = new MongoClient("mongodb://localhost");
                MongoServer server = client.GetServer();
                MongoDatabase db = server.GetDatabase("Zdata");
                MongoCursor<anim> put = db.GetCollection<anim>("Animals").FindAll();

                foreach (anim i in put)
                {

                    if (textBox1.Text == Convert.ToString(i.pid))
                    {
                        label16.Text = "Id  Exists";
                        if (Menuanim.mode == 2)
                        {
                            textBox3.Text = i.animal;
                            textBox4.Text = i.species;
                            dateTimePicker1.Text = i.DoB;
                            comboBox2.Text = i.captivity;
                            comboBox1.Text = i.category;
                            textBox7.Text = i.health;
                            textBox8.Text = i.csstatus;
                            textBox9.Text = i.location;
                            textBox10.Text = i.origin;
                            String FileName = @"" + folder + i.pid + ".jpg";
                            if (System.IO.File.Exists(@"" + folder + Convert.ToSingle(i.pid) + ".jpg"))
                            {
                                System.IO.FileStream fm = new System.IO.FileStream(FileName, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                                pictureBox1.Image = System.Drawing.Image.FromStream(fm);//Image.FromFile(@"" + opn.FileName);

                                fm.Dispose();
                                fm.Close(); 
                            }



                        }
                    }
                    else
                    {

                        label16.Text = "Id Not Exists";

                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            textBox2.Show();
            label18.Show();


        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Menuanim n = new Menuanim();
            n.Show();
            this.Hide();
        }
    }
    }

       