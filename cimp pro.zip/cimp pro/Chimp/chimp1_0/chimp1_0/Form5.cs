﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MongoDB.Driver;
using MongoDB.Driver.Builders;

namespace chimp1_0
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
            Form7 f7=new Form7();

            if (f7.ucheck(textBox1.Text) == 1)
            {
               
                MongoClient client = new MongoClient("mongodb://localhost");
                MongoServer server = client.GetServer();
                MongoDatabase db = server.GetDatabase("Zdata");
                MongoCollection<user> staff = db.GetCollection<user>("dstaff");
                if (staff.Remove(Query.EQ("username", textBox1.Text)).Ok == true)
                    MessageBox.Show("Record successfully deleted!");
            }
            else
                MessageBox.Show("Record Not Found");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
             Form7 f7=new Form7();

             if (f7.ucheck(textBox1.Text) == 1)
             {
                 label4.Text = "User found";
             }
             else
                 label4.Text = "User not found";
        }
    }
}
