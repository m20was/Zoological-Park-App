﻿using MongoDB.Bson;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chimp1_0
{
    class fund
    {
        public ObjectId _id { get; set; }
        public string Date { get; set; }
        public int Gov_fund { get; set; }
        public int Donation { get; set; }
        public int Sponsors { get; set; }
        public int  Spevent { get; set; }
        public string stock { get; set; }
        public int MeatQ { get; set; }
        public int MeatC { get; set; }
        public int VegQ { get; set; }
        public int VegC { get; set; }
        public int Sanitation { get; set; }
        public Boolean welding { get; set; }
        public Boolean plumbing { get; set; }
        public Boolean repair { get; set; }
        public Boolean spare { get; set; }
        public int Hc { get; set; }
        public int es { get; set; }
        public int tc { get; set; }
        public int ws { get; set; }

        public int exc { get; set; }


    }
}
